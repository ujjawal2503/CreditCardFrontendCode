import React, { Component } from 'react';

class Footer extends Component {
    render() {
        return (
    
            <div class="footer">
  <h3>Created and Maintained by Group-1 Btach-2 JEE Full Stack with React</h3>
</div>
        );
    }
}

export default Footer;